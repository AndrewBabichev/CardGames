from  .code.menu import start_app
import os

if __name__ == '__main__':
    print(os.getcwd())
    start_app()
